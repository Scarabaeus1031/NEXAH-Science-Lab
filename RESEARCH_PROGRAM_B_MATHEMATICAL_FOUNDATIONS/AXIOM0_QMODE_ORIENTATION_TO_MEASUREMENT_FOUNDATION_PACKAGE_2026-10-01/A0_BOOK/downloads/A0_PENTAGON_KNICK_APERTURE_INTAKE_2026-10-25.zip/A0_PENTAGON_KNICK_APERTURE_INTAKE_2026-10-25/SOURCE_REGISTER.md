# Source Register

## Interaktiver Bestand

| Datei | Rolle | Disposition |
|---|---|---|
| `NEXAH_PENTAGON_KNICK_APERTURE_LAB.html` | jüngster eindeutiger Instrumentstand | Intake-Kandidat, keine Admission |
| `sources/html-history/01-base.html` | frühe Pentagon/Knick-Fassung | Provenienz |
| `sources/html-history/02-ring.html` | Ring-/Apertur-Fassung | Provenienz |
| `sources/html-history/03-graph.html` | Graph-/Routen-Fassung | Provenienz |

Die Datei `NEXAH_Pentagon_Knick_Lab-2 copy.html` war byte-identisch mit dem übernommenen jüngsten Stand und wurde deshalb nicht doppelt abgelegt.

## Direkte Visuals

| Datei | Lesart | Grenze |
|---|---|---|
| `01-central-ring-five-windows.png` | zentrale Öffnung und fünf äußere Zwischenräume | virtuelle Messflächen |
| `02-lab-reference-preset.png` | interaktiver Referenzzustand | keine Stabilitätsaussage |
| `03-lab-flat-preset.png` | flacher zulässiger Zustand | keine Mechanikbehauptung |
| `04-ten-fields-rgb-route.png` | zehn Teilfelder und Zwei-Schritt-Weg | Ansichtsregel, keine neue Graphkante |
| `05-11-winds-reference.png` | elf adressierte Pin→Hüllenecke-Richtungen | ungleich verteilt, keine Elfer-Symmetrie |

## Kontext

`context/NEXAH_Arbeitsstand_2026-10-24.txt` ist ein datierter Arbeitsstand und ausschließlich Kontext. Er ersetzt weder aktuelle Registry, Binder, Desk noch Source Graph.

Die fünf Dateien in `visuals/context/` bewahren D-Spalt/Horizont, gegensinnige Pentagon-Drehung, Zwischenraum, Fibonacci/Euler-Ziffernschnitt und Spur/Projektion als benachbarte Arbeitsspuren. Sie sind keine Quellen für die Lab-Geometrie und werden durch die gemeinsame Ablage nicht zu einem Operator oder Mechanismus verbunden. Zwei zusätzliche Photos-Library-Dateien waren byte-identisch mit `01-central-ring-five-windows.png` und `04-ten-fields-rgb-route.png` und wurden nicht doppelt abgelegt.
