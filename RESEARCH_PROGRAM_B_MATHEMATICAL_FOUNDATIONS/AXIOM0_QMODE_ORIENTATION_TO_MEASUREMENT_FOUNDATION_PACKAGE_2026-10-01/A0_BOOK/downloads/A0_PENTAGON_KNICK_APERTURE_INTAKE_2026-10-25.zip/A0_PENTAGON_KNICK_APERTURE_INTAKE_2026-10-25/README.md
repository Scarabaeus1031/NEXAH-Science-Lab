# A0 Pentagon · Knick · Apertur Intake

Stand: 25. Oktober 2026  
Status: `PARKED_SOURCE_BOUND_INTAKE_NO_ADMISSION`

Dieses Paket sichert den interaktiven Pentagon-Knick-Demonstrator, seine drei unterscheidbaren Vorstufen, fünf direkte Referenzvisuals, fünf getrennte Kontextvisuals und den datierten Arbeitskontext. Es ist ein Intake für spätere wissenschaftliche Prüfung, keine aktivierte Study und kein neues Finding.

## Was bereits belastbar ist

- Zwei parallele Pentagonrahmen mit fünf gegliederten Verbindungen sind als endlicher Geometrie-Demonstrator implementiert.
- Höhe, wirksame Spannweite, zentrale Öffnung, Querstrebenlänge und Messfenster sind für deklarierte Parameter berechenbar.
- Die zehn Seitenfelder und der nicht-zurücklaufende Zwei-Schritt-Weg sind im Instrument als getrennte Ansichtsebenen geführt.
- `11 Winds` adressiert elf ungleich verteilte Richtungen vom Pin zu vorhandenen Hüllenecken. Die A/B/M-Namen bleiben erhalten; Randzugehörigkeit darf mit der Ansicht wechseln.

## Was ausdrücklich nicht behauptet wird

- keine Stabilität, Dynamik oder physikalische Mechanik;
- keine regelmäßige Elfer-Symmetrie und keine elf zusätzlichen Gelenke;
- keine Gleichsetzung von Ansichtsflächen, Streben und Graphkanten;
- kein Ihara-, A0-, NSN- oder OPIUM-Operator aus visueller Ähnlichkeit;
- keine neue kanonische Identität oder Source-Graph-Relation.

## Bestehende Rückbindungen

- A0 Science Desk: Intake, Grenzen und nächster Prüfweg;
- Builder Log: gebaute Oberfläche und OPIUM-Ansichtsadapter;
- NSN: dokumentarische Quellenbindung unter `NEXAH:A0_ORIENTATION_EVIDENCE_LINEAGE:V1`, mit Wiederverwendung von `ART:A0:MATHEMATICAL_JOINTS` und `MOD:TESSAREC`;
- OPIUM: `11 Winds` ausschließlich als animierte, abschaltbare Display-Schicht des vorhandenen Plattenstapels.

Start: [NEXAH_PENTAGON_KNICK_APERTURE_LAB.html](NEXAH_PENTAGON_KNICK_APERTURE_LAB.html)  
Arbeitsauftrag: [CODEX_INTAKE.md](CODEX_INTAKE.md)  
Quellen: [SOURCE_REGISTER.md](SOURCE_REGISTER.md)
